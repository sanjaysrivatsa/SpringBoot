package Cart.Cart;
import java.util.ArrayList;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CartController {
	ArrayList <String> items=new ArrayList();
	public CartController()
	{
		items.add("IPhone"); items.add("Clocks");
	}
	@RequestMapping(value="/Add")
	public void Add(@PathVariable String  itemname)
	{
		items.add(itemname);
		System.out.println("Item added...");
	}
	@RequestMapping(value="/show")
	public String showItems()
	{
		String item="";
		for(int i=0;i < items.size(); i++)
		 item += items.get(i) + "\t\t";
		return item;
	}
}
