package SpringDataJPA.SpringDataJPA;
import java.util.HashMap;

import  SpringDataJPA.SpringDataJPA.model.*;
public class DatabaseMock {
	HashMap  <Integer, Player>players =new HashMap();
	public boolean update(Player  play)
	{
		System.out.println("Player details updated...");
		if(players.get(play.getPlayerId()) == null)
			return false;
		else
			players.put(play.getPlayerId(), play);
		return true;
	}
	public Player  select(int  playerId)
	{
		return  players.get(playerId);
	}
	public boolean  insert(Player  play)
	{
		
		System.out.println("Player details added...");
		if(players.get(play.getPlayerId()) == null)
		{
				players.put(play.getPlayerId(), play);
				return true;
		}
		return false;
	}
	public Player  delete(int  playerId)
	{
		System.out.println("Player details deleted...");
		return players.remove(playerId);
	}
}
