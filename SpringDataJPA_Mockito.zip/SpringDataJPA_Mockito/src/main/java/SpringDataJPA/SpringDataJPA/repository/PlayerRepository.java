package SpringDataJPA.SpringDataJPA.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import SpringDataJPA.SpringDataJPA.model.Player;
/*
 * C - Create (Insert)
 * R - Read(query)
 * U - Update
 * D - Delete

	All the CRUD operations like Save(), saveAll(), delete(), deleteAll(), find(), 
	findAll() etc., are automatically implemented
	
 * 
 */
@Repository
public interface PlayerRepository extends CrudRepository<Player, Integer> {
	//findPlayers () is a user-defined method
	// ?1 will get replaced with value of playerId
	@Query("select   p from Player p where p.playerId < ?1")
	public List<Player> findPlayers(Integer  playerId);

	//For DML operations
	@Modifying 
	@Query("update  Player  p set p.noOfMatches=?2 where p.playerId=?1")
	public void updatePlayerMatch(Integer playerId, Integer noOfMatches);
}
