package  SpringDataJPA.SpringDataJPA.model;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

//combo of Entity and Table annotation
@Embeddable
@Entity
public class Player {
	@Id
	@Column(name="playerid")
	int playerId;
	@Column(name="playername", nullable=false)
	String playerName;
	@Column(name="noofmatches",nullable=false)
	int noOfMatches;

	@Column(name="teamid")
	String  teamId;

	
	public Player()
	{
	}
	public Player(int playerId, String playerName, int noOfMatches, String  teamId) {
		super();
		this.playerId = playerId;
		this.playerName = playerName;
		this.noOfMatches = noOfMatches;
		this.teamId = teamId;
		//this.iplteam=iplteam;
	}
	public int getPlayerId() {
		return playerId;
	}
	public void setPlayerId(int playerId) {
		this.playerId = playerId;
	}
	public String getPlayerName() {
		return playerName;
	}
	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}
	public int getNoOfMatches() {
		return noOfMatches;
	}
	public void setNoOfMatches(int noOfMatches) {
		this.noOfMatches = noOfMatches;
	}
	public String getTeamId() {
		return teamId;
	}
	public void setTeamId(String teamId) {
		this.teamId = teamId;
	}
	@Override
	public String toString() {
		return "Player [playerId=" + playerId + ", playerName=" + playerName + ", noOfMatches=" + noOfMatches 
				+", teamId = " + teamId	+  "]";
	}
}