package SpringDataJPA.SpringDataJPA;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import javax.websocket.server.PathParam;

import org.junit.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.RequestEntity;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import SpringDataJPA.SpringDataJPA.model.Player;
import SpringDataJPA.SpringDataJPA.repository.PlayerRepository;
import net.bytebuddy.dynamic.DynamicType.Builder.FieldDefinition.Optional;

@Controller
public class PlayerController {

	//Automatically injects PlayerRepository bean into this controller.
	
	@Mock
	private DatabaseMock  dbmock;

	@Test
	@ResponseBody
	@PostMapping(value="/add", consumes=MediaType.APPLICATION_JSON_VALUE)
	public String  addPlayer()
	{
		//playerRepo.save(play);
		Player  play=new Player(101, "Rohit Sharma", 150, "MI");
		assertTrue(dbmock.insert(play), 
				play.getPlayerName() + " already present....");
		return "<B>Player added</B>";
	}

	
	@Test
	@ResponseBody
	@RequestMapping("/getId")
	public String  getGivenPlayer()
	{
		//java.util.Optional<Player> play=playerRepo.findById(playerId);
		//return  play.toString();
		int playerId=100;
		assertNotNull("Invalid player ID", dbmock.select(playerId));
		return "Tested";
	}

	@Test
	@ResponseBody
	@PutMapping(value="/updateMatches")
	//Indicating that you are performing a DML statement
	//@Transactional
	public  String  updateMatch()
	{
		Player  play=new Player(101, "Jasprit Bumrah", 150, "MI");
		assertTrue(dbmock.update(play), "Player not found");
		return "<B>Updated player with ID </B>" + play.getPlayerId();
	}
	
	@Test
	@ResponseBody
	@RequestMapping("/deleteId")
	public String deletePlayer()
	{
		int  playerId=100;
		assertNotNull("Invalid player ID", dbmock.delete(playerId));
		String response= "<B>Deleted player with ID </B>" + playerId;
//		response += "<BR><BR><B>No of players after delete : </B>" + playerRepo.count();
		return  response;
	}
}
