package BackendCart.BackendCart;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CartController {
	ArrayList <String> items=new ArrayList();
	
	@GetMapping("/")
	public String health()
	{
		return "I am OK"; 
	}
	public CartController()
	{
		items.add("IPhone"); items.add("Clocks");
	}
	@RequestMapping(value="/Add")
	public void Add(@PathVariable String  itemname)
	{
		items.add(itemname);
		System.out.println("Item added...");
	}
	@RequestMapping(value="/show")
	public String showItems()
	{
		String item="";
		for(int i=0;i < items.size(); i++)
		 item += items.get(i) + "\t\t";
		return item;
	}
	@GetMapping("/backend")
	public String backend()
	{
		String serverport=env.getProperty("local.server.port");
		System.out.println("Port : " + serverport);
		return "BackendCart Port - " + serverport;
	}
	@Autowired
	Environment  env;
}
